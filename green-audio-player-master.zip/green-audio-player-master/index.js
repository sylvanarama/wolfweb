module.exports = require('./src/js/main').default;
